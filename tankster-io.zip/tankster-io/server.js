const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const WebSocket = require("ws");

const PORT = Number(process.env.PORT || 8080);
const ROOT = path.join(__dirname, "public");
const server = http.createServer((req, res) => {
  let pathname = decodeURIComponent((req.url || "/").split("?")[0]);
  if (pathname === "/") pathname = "/index.html";
  const filePath = path.normalize(path.join(ROOT, pathname));
  if (!filePath.startsWith(ROOT)) {
    res.writeHead(403); return res.end("Forbidden");
  }
  fs.readFile(filePath, (err, data) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(filePath);
    const types = { ".html":"text/html; charset=utf-8", ".css":"text/css; charset=utf-8", ".js":"text/javascript; charset=utf-8", ".json":"application/json" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream", "Cache-Control":"no-cache" });
    res.end(data);
  });
});

const wss = new WebSocket.Server({ server });
const WORLD = { width: 3600, height: 2400 };
const players = new Map();
const bullets = new Map();
const shapes = new Map();
const MAX_PLAYERS = 80;
const SHAPE_COUNT = 180;
const TICK_MS = 50;
let nextBulletId = 1;

function rand(min, max) { return Math.random() * (max - min) + min; }
function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }
function makeShape() {
  const roll = Math.random();
  const type = roll < 0.62 ? "square" : roll < 0.88 ? "triangle" : "pentagon";
  return {
    id: crypto.randomUUID(), type, x: rand(100, WORLD.width - 100), y: rand(100, WORLD.height - 100),
    r: type === "square" ? 18 : type === "triangle" ? 22 : 29,
    hp: type === "square" ? 20 : type === "triangle" ? 45 : 110,
    maxHp: type === "square" ? 20 : type === "triangle" ? 45 : 110,
    xp: type === "square" ? 10 : type === "triangle" ? 25 : 70
  };
}
for (let i = 0; i < SHAPE_COUNT; i++) { const s = makeShape(); shapes.set(s.id, s); }

function tankForLevel(level) {
  if (level >= 30) return "Overlord";
  if (level >= 22) return "Twin";
  if (level >= 15) return "Machine Gun";
  if (level >= 8) return "Sniper";
  return "Basic";
}
function newPlayer(ws) {
  const id = crypto.randomUUID();
  return {
    id, ws, name: "Tank-" + Math.floor(rand(100, 9999)), x: rand(250, WORLD.width-250), y: rand(250, WORLD.height-250),
    angle: 0, radius: 22, hp: 100, maxHp: 100, xp: 0, level: 1, score: 0, kills: 0,
    tank: "Basic", color: ["#58d7ff", "#a78bfa", "#ffbd59", "#62e6a7", "#ff7b91"][Math.floor(Math.random()*5)],
    stats: { damage: 1, reload: 1, speed: 1, health: 1, bulletSpeed: 1 },
    input: { up:false, down:false, left:false, right:false, fire:false, angle:0 },
    lastShot: 0, lastHit: 0, invulnerableUntil: Date.now() + 1500
  };
}
function publicPlayer(p) {
  return { id:p.id, name:p.name, x:p.x, y:p.y, angle:p.angle, radius:p.radius, hp:p.hp, maxHp:p.maxHp,
    xp:p.xp, level:p.level, score:p.score, kills:p.kills, tank:p.tank, color:p.color, stats:p.stats };
}
function send(ws, obj) { if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj)); }
function addXP(p, amount) {
  p.xp += amount; p.score += amount;
  while (p.level < 45 && p.xp >= xpForLevel(p.level + 1)) p.level++;
  p.tank = tankForLevel(p.level);
  p.maxHp = 100 + (p.level - 1) * 4 + (p.stats.health - 1) * 18;
  p.hp = Math.min(p.maxHp, p.hp + amount * 0.18);
}
function xpForLevel(level) { return Math.floor(40 * Math.pow(level, 1.42)); }
function resetPlayer(p) {
  p.x = rand(180, WORLD.width-180); p.y = rand(180, WORLD.height-180);
  p.hp = p.maxHp; p.invulnerableUntil = Date.now() + 1800;
}
function spawnBullet(p) {
  const now = Date.now();
  const reload = Math.max(100, 360 / p.stats.reload * (p.tank === "Machine Gun" ? 0.58 : 1) * (p.tank === "Twin" ? 0.8 : 1));
  if (now - p.lastShot < reload) return;
  p.lastShot = now;
  const angle = p.input.angle || p.angle;
  const count = p.tank === "Twin" ? 2 : p.tank === "Overlord" ? 3 : 1;
  for (let i = 0; i < count; i++) {
    const spread = count === 1 ? 0 : (i - (count-1)/2) * 0.16;
    const a = angle + spread;
    const speed = 560 * p.stats.bulletSpeed;
    const id = nextBulletId++;
    bullets.set(id, { id, owner:p.id, x:p.x + Math.cos(a)*28, y:p.y + Math.sin(a)*28,
      vx:Math.cos(a)*speed, vy:Math.sin(a)*speed, r:7, damage:17*p.stats.damage*(p.tank==="Sniper"?1.6:1), life:1250, color:p.color });
  }
}
wss.on("connection", ws => {
  if (players.size >= MAX_PLAYERS) { send(ws,{type:"full"}); return ws.close(); }
  const p = newPlayer(ws); players.set(p.id,p);
  send(ws, { type:"welcome", id:p.id, world:WORLD, player:publicPlayer(p), xpNext:xpForLevel(2) });
  ws.on("message", raw => {
    let msg; try { msg = JSON.parse(raw.toString()); } catch { return; }
    if (msg.type === "input") {
      const i = msg.input || {};
      p.input.up = !!i.up; p.input.down = !!i.down; p.input.left = !!i.left; p.input.right = !!i.right; p.input.fire = !!i.fire;
      if (Number.isFinite(i.angle)) p.input.angle = i.angle;
    } else if (msg.type === "name") {
      const n = String(msg.name || "").replace(/[<>]/g,"").trim().slice(0,16);
      if (n) p.name = n;
    } else if (msg.type === "upgrade") {
      const key = String(msg.stat || "");
      const usedPoints = Object.values(p.stats).reduce((a, v) => a + v - 1, 0);
      const availablePoints = Math.max(0, p.level - 1 - usedPoints);
      if (p.level > 1 && availablePoints > 0 && ["damage","reload","speed","health","bulletSpeed"].includes(key) && p.stats[key] < 8) {
        p.stats[key]++;
        if (key === "health") { p.maxHp += 18; p.hp = Math.min(p.maxHp, p.hp + 18); }
      }
    } else if (msg.type === "evolve") {
      if (p.level >= 15 && ["Twin","Sniper","Machine Gun","Overlord"].includes(msg.tank)) p.tank = msg.tank;
    }
  });
  ws.on("close", () => players.delete(p.id));
  ws.on("error", () => players.delete(p.id));
});

let previous = Date.now();
setInterval(() => {
  const now = Date.now(), dt = Math.min(0.08, (now - previous)/1000); previous = now;
  for (const p of players.values()) {
    const i = p.input;
    let dx = (i.right?1:0) - (i.left?1:0), dy = (i.down?1:0) - (i.up?1:0);
    const len = Math.hypot(dx,dy) || 1;
    const speed = 250 * p.stats.speed * (p.tank === "Overlord" ? 0.92 : 1);
    p.x = clamp(p.x + dx/len*speed*dt, 35, WORLD.width-35);
    p.y = clamp(p.y + dy/len*speed*dt, 35, WORLD.height-35);
    if (Number.isFinite(i.angle)) p.angle = i.angle;
    if (i.fire) spawnBullet(p);
  }
  for (const [id,b] of bullets) {
    b.x += b.vx*dt; b.y += b.vy*dt; b.life -= dt*1000;
    if (b.life <= 0 || b.x<0 || b.y<0 || b.x>WORLD.width || b.y>WORLD.height) { bullets.delete(id); continue; }
    let hit = false;
    for (const s of shapes.values()) {
      if (Math.hypot(s.x-b.x,s.y-b.y) < s.r+b.r) {
        s.hp -= b.damage;
        if (s.hp <= 0) { shapes.delete(s.id); const owner=players.get(b.owner); if(owner) addXP(owner,s.xp); }
        hit = true; break;
      }
    }
    if (!hit) {
      for (const target of players.values()) {
        if (target.id === b.owner || Date.now() < target.invulnerableUntil) continue;
        if (Math.hypot(target.x-b.x,target.y-b.y) < target.radius+b.r) {
          target.hp -= b.damage; target.lastHit = Date.now();
          if (target.hp <= 0) {
            const owner=players.get(b.owner);
            if(owner) { owner.kills++; addXP(owner, 80 + target.level*12); }
            target.xp = Math.floor(target.xp*0.7); target.level = Math.max(1, Math.floor(target.level*0.85));
            target.stats = {damage:1,reload:1,speed:1,health:1,bulletSpeed:1};
            target.tank = tankForLevel(target.level); resetPlayer(target);
          }
          hit = true; break;
        }
      }
    }
    if (hit) bullets.delete(id);
  }
  if (shapes.size < SHAPE_COUNT) { const s=makeShape(); shapes.set(s.id,s); }
  const state = {
    type:"state", world:WORLD,
    players:[...players.values()].map(p => ({...publicPlayer(p), upgradePoints:Math.max(0,p.level-1 - Object.values(p.stats).reduce((a,v)=>a+v-1,0))})),
    bullets:[...bullets.values()],
    shapes:[...shapes.values()]
  };
  const payload = JSON.stringify(state);
  for (const p of players.values()) if (p.ws.readyState === WebSocket.OPEN) p.ws.send(payload);
}, TICK_MS);

server.listen(PORT, "0.0.0.0", () => console.log(`Tankster.io running on http://0.0.0.0:${PORT}`));
