(() => {
  const $ = id => document.getElementById(id);
  const connectionEl = $("connection"), onlineEl = $("playersOnline"), menu = $("menu"), hud = $("hud");
  const state = { id:null, world:{width:3600,height:2400}, players:[], bullets:[], shapes:[], me:null, started:false, keys:{}, fire:false, joy:{x:0,y:0}, pointer:{x:0,y:0}, ws:null, scene:null };
  let toastTimer;
  function toast(msg){const el=$("toast");el.textContent=msg;el.classList.add("show");clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove("show"),1800);}
  function wsURL(){return (location.protocol==="https:"?"wss://":"ws://")+location.host;}
  function connect(){
    try{
      state.ws = new WebSocket(wsURL());
      state.ws.onopen=()=>{connectionEl.textContent="CONNECTED";connectionEl.previousElementSibling.style.background="#6cf5bd";};
      state.ws.onclose=()=>{connectionEl.textContent="RECONNECTING";connectionEl.previousElementSibling.style.background="#ffbd59";setTimeout(connect,1600);};
      state.ws.onerror=()=>{connectionEl.textContent="OFFLINE";};
      state.ws.onmessage=e=>{let msg;try{msg=JSON.parse(e.data)}catch{return}
        if(msg.type==="welcome"){state.id=msg.id;state.world=msg.world;state.me=msg.player;toast("Connected to Tankster arena");}
        if(msg.type==="full")toast("Arena is full. Try again in a moment.");
        if(msg.type==="state"){state.players=msg.players;state.bullets=msg.bullets;state.shapes=msg.shapes;state.world=msg.world;state.me=state.players.find(p=>p.id===state.id)||state.me;onlineEl.textContent=state.players.length+" ONLINE";updateHUD();}
      };
    }catch(e){connectionEl.textContent="OFFLINE";}
  }
  function send(obj){if(state.ws&&state.ws.readyState===WebSocket.OPEN)state.ws.send(JSON.stringify(obj));}
  function startGame(){
    const name=$("playerName").value.trim().slice(0,16)||"Tankster";
    send({type:"name",name}); $("hudName").textContent=name;
    state.started=true;menu.classList.add("hidden");hud.classList.add("active");
    if(state.scene)state.scene.cameras.main.fadeIn(350,8,14,28);
  }
  $("playButton").addEventListener("click",startGame);
  $("playerName").addEventListener("keydown",e=>{if(e.key==="Enter")startGame();});
  document.querySelectorAll("[data-stat]").forEach(btn=>btn.addEventListener("click",()=>send({type:"upgrade",stat:btn.dataset.stat})));
  document.querySelectorAll("[data-tank]").forEach(btn=>btn.addEventListener("click",()=>send({type:"evolve",tank:btn.dataset.tank})));

  window.addEventListener("keydown",e=>{state.keys[e.key.toLowerCase()]=true;if(["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"," "].includes(e.key))e.preventDefault();});
  window.addEventListener("keyup",e=>state.keys[e.key.toLowerCase()]=false);
  window.addEventListener("blur",()=>{state.keys={};state.fire=false;});
  window.addEventListener("pointermove",e=>{state.pointer.x=e.clientX;state.pointer.y=e.clientY;});
  window.addEventListener("pointerdown",e=>{if(e.target.closest("button,input,.joystick"))return;state.fire=true;});
  window.addEventListener("pointerup",()=>state.fire=false);
  const joy=$("joystick"), knob=$("joyKnob"), fireBtn=$("fireButton");
  let joyPointer=null;
  function updateJoy(e){const r=joy.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const max=37,len=Math.hypot(dx,dy);if(len>max){dx=dx/len*max;dy=dy/len*max;}state.joy.x=dx/max;state.joy.y=dy/max;knob.style.left=`calc(50% + ${dx}px)`;knob.style.top=`calc(50% + ${dy}px)`;}
  joy.addEventListener("pointerdown",e=>{joyPointer=e.pointerId;joy.setPointerCapture(e.pointerId);updateJoy(e);});
  joy.addEventListener("pointermove",e=>{if(joyPointer===e.pointerId)updateJoy(e);});
  function resetJoy(){joyPointer=null;state.joy={x:0,y:0};knob.style.left="50%";knob.style.top="50%";}
  joy.addEventListener("pointerup",resetJoy);joy.addEventListener("pointercancel",resetJoy);
  fireBtn.addEventListener("pointerdown",e=>{e.preventDefault();state.fire=true;fireBtn.setPointerCapture(e.pointerId);});
  fireBtn.addEventListener("pointerup",()=>state.fire=false);fireBtn.addEventListener("pointercancel",()=>state.fire=false);

  function updateHUD(){
    const p=state.me;if(!p)return;
    $("level").textContent=p.level;$("score").textContent=Math.floor(p.score).toLocaleString();$("kills").textContent=p.kills;
    $("tankClass").textContent=(p.tank||"Basic").toUpperCase()+" TANK";
    $("hpText").textContent=Math.ceil(p.hp)+" / "+Math.ceil(p.maxHp);
    $("hpFill").style.width=Math.max(0,p.hp/p.maxHp*100)+"%";
    const currentXP=p.xp, next=Math.floor(40*Math.pow(p.level+1,1.42)), prev=p.level===1?0:Math.floor(40*Math.pow(p.level,1.42));
    $("xpFill").style.width=Math.max(0,Math.min(100,(currentXP-prev)/Math.max(1,next-prev)*100))+"%";
    $("xpText").textContent=Math.floor(currentXP)+" XP";
    const used=Object.values(p.stats||{}).reduce((a,v)=>a+v-1,0), points=Math.max(0,p.level-1-used);
    $("points").textContent=points+" POINTS";
    document.querySelectorAll("[data-stat]").forEach(b=>{const k=b.dataset.stat;b.disabled=points<=0||(p.stats[k]||1)>=8;$(`${k}Lv`).textContent=(p.stats[k]||1)+"/8";});
    $("upgradePanel").classList.toggle("visible",state.started&&p.level>=2);
    $("evolvePanel").classList.toggle("visible",state.started&&p.level>=15);
    document.querySelectorAll("[data-tank]").forEach(b=>b.disabled=p.level<15);
    const sorted=[...state.players].sort((a,b)=>b.score-a.score).slice(0,5);
    $("leaderRows").innerHTML=sorted.map((x,i)=>`<div class="leader-row ${x.id===state.id?"me":""}"><span>${i+1}. ${escapeHTML(x.name)}</span><strong>${Math.floor(x.score).toLocaleString()}</strong></div>`).join("");
  }
  function escapeHTML(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}

  const config={type:Phaser.AUTO,parent:"game",backgroundColor:"#0a1122",scale:{mode:Phaser.Scale.RESIZE,width:"100%",height:"100%"},render:{antialias:true},scene:{create,update}};
  const game=new Phaser.Game(config);
  function create(){
    state.scene=this;this.cameras.main.setBackgroundColor("#0a1122");
    this.grid=this.add.graphics().setDepth(-10);this.drawGrid();
    this.shapeGraphics=this.add.graphics();this.bulletGraphics=this.add.graphics();this.tankGraphics=this.add.graphics();
    this.labels=this.add.container();this.cameras.main.setBounds(0,0,state.world.width,state.world.height);
    this.cameras.main.setZoom(Math.min(1,window.innerWidth/1100));
    this.input.on("pointermove",p=>{state.pointer.x=p.x;state.pointer.y=p.y;});
    this.scale.on("resize",()=>{this.drawGrid();});
    connect();
  }
  function drawGrid(){
    if(!state.scene)return;
    const g=state.scene.grid;g.clear();g.lineStyle(1,0x20314d,.45);
    for(let x=0;x<=state.world.width;x+=80){g.beginPath();g.moveTo(x,0);g.lineTo(x,state.world.height);g.strokePath();}
    for(let y=0;y<=state.world.height;y+=80){g.beginPath();g.moveTo(0,y);g.lineTo(state.world.width,y);g.strokePath();}
    g.lineStyle(5,0x314b70,.75);g.strokeRect(0,0,state.world.width,state.world.height);
  }
  function drawTank(g,p,isMe){
    const color=Phaser.Display.Color.HexStringToColor(p.color||"#53d7ff").color;
    g.fillStyle(0x000000,.23);g.fillCircle(p.x+3,p.y+5,p.radius+3);
    const angle=p.angle||0, barrels=p.tank==="Twin"?[-.15,.15]:p.tank==="Overlord"?[-.22,0,.22]:[0];
    barrels.forEach(offset=>{
      const a=angle+offset;g.lineStyle(1,0x091222,.8);g.fillStyle(color,1);
      const bx=p.x+Math.cos(a)*9,by=p.y+Math.sin(a)*9;
      const ex=p.x+Math.cos(a)*(p.radius+17),ey=p.y+Math.sin(a)*(p.radius+17);
      g.fillRoundedRect(Math.min(bx,ex)-5,Math.min(by,ey)-5,Math.abs(ex-bx)+10,Math.abs(ey-by)+10,3);
    });
    g.fillStyle(color,1);g.lineStyle(3,0x0a1428,1);g.fillCircle(p.x,p.y,p.radius);g.strokeCircle(p.x,p.y,p.radius);
    g.fillStyle(0xeaf8ff,.8);g.fillCircle(p.x-Math.cos(angle)*4,p.y-Math.sin(angle)*4,4);
    if(isMe){g.lineStyle(2,0x8cecff,.9);g.strokeCircle(p.x,p.y,p.radius+6);}
    const w=42;g.fillStyle(0x152139,1);g.fillRoundedRect(p.x-w/2,p.y-p.radius-16,w,4,2);
    g.fillStyle(p.hp/p.maxHp>.35?0x6cf5bd:0xff697d,1);g.fillRoundedRect(p.x-w/2,p.y-p.radius-16,w*Math.max(0,p.hp/p.maxHp),4,2);
  }
  function update(time,delta){
    if(!state.scene)return;
    const me=state.me;
    if(state.started&&me){
      const k=state.keys,j=state.joy;
      const input={up:!!(k.w||k.arrowup||j.y<-.22),down:!!(k.s||k.arrowdown||j.y>.22),left:!!(k.a||k.arrowleft||j.x<-.22),right:!!(k.d||k.arrowright||j.x>.22),fire:state.fire||!!k[" "],angle:me.angle||0};
      const pointerWorld=this.cameras.main.getWorldPoint(state.pointer.x,state.pointer.y);
      if(state.pointer.x||state.pointer.y)input.angle=Math.atan2(pointerWorld.y-me.y,pointerWorld.x-me.x);
      if(Math.abs(j.x)+Math.abs(j.y)>.25)input.angle=Math.atan2(j.y,j.x);
      send({type:"input",input});
    }
    this.shapeGraphics.clear();this.bulletGraphics.clear();this.tankGraphics.clear();this.labels.removeAll(true);
    for(const s of state.shapes){
      const col=s.type==="square"?0xffca69:s.type==="triangle"?0x68e8b6:0xc2a0ff;
      this.shapeGraphics.fillStyle(col,1);this.shapeGraphics.lineStyle(2,0x091426,.9);
      if(s.type==="square")this.shapeGraphics.fillRoundedRect(s.x-s.r,s.y-s.r,s.r*2,s.r*2,4);
      else if(s.type==="triangle"){this.shapeGraphics.fillTriangle(s.x,s.y-s.r,s.x-s.r,s.y+s.r*.7,s.x+s.r,s.y+s.r*.7);}
      else {const pts=[];for(let i=0;i<5;i++){const a=-Math.PI/2+i*Math.PI*2/5;pts.push({x:s.x+Math.cos(a)*s.r,y:s.y+Math.sin(a)*s.r});}this.shapeGraphics.fillPoints(pts,true);}
      this.shapeGraphics.strokeCircle(s.x,s.y,s.r+1);
    }
    for(const b of state.bullets){const c=Phaser.Display.Color.HexStringToColor(b.color||"#53d7ff").color;this.bulletGraphics.fillStyle(c,1);this.bulletGraphics.fillCircle(b.x,b.y,b.r);this.bulletGraphics.fillStyle(c,.2);this.bulletGraphics.fillCircle(b.x,b.y,b.r*2.1);}
    for(const p of state.players){drawTank(this.tankGraphics,p,p.id===state.id);const t=this.add.text(p.x,p.y-p.radius-31,p.name,{fontFamily:"Inter, sans-serif",fontSize:"11px",fontStyle:"bold",color:p.id===state.id?"#8cecff":"#c5d4ec",stroke:"#081020",strokeThickness:3}).setOrigin(.5);this.labels.add(t);}
    if(me){this.cameras.main.centerOn(me.x,me.y);this.cameras.main.setZoom(Math.min(1,window.innerWidth/1100));}
  }
})();
