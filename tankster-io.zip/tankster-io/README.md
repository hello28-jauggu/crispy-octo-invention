# Tankster.io

An original browser-based multiplayer tank arena built with Phaser 3, Node.js, and WebSockets. It includes real-time player state, mobile joystick controls, shooting, shapes for XP, levels, stat upgrades, a leaderboard, and tank evolution.

## Requirements
- Node.js 18 or newer
- Internet connection for the Phaser CDN and Google Fonts (the game itself is served locally)

## Start on GitHub Codespaces (mobile)
1. Upload/extract this project into a GitHub repository.
2. Open the repository in GitHub Codespaces.
3. In the terminal, run:

```bash
npm install
npm start
```

4. Codespaces will show that port `8080` is forwarded. Open the forwarded port in a browser. If it is private, set port visibility to **Public** only if you want other people to join.
5. Keep the Codespace running while playing; a stopped Codespace stops the server.

## Start on Android with Termux
Install Node.js in Termux, then navigate to the folder containing this project and run:

```bash
npm install
npm start
```

Open `http://127.0.0.1:8080` on the same phone. This local address is only accessible from your phone; to let friends join, deploy the server or use a suitable tunnel and follow its security rules.

## Exact unzip commands
If the ZIP is in the phone's `Download` folder in Termux:

```bash
termux-setup-storage
cd ~/storage/downloads
unzip tankster-io.zip -d tankster-io
cd tankster-io
npm install
npm start
```

If your ZIP has a different filename, replace `tankster-io.zip` with the actual filename.

## Controls
- Desktop: WASD / arrow keys to move, mouse to aim, hold mouse button or Space to fire.
- Mobile: left virtual joystick to move, FIRE to shoot. Aim by dragging on the arena.
- Upgrade buttons appear after level 2. Tank evolution appears at level 15.

## Important notes
- This is a playable first version, not a production-hardened game server. It uses a basic authoritative movement loop and simple collision checks.
- Player names and messages are not an account system; progress is not saved between sessions.
- For a public launch, add rate limits, stronger server-side input validation, persistence, moderation, deployment monitoring, and capacity testing.
- Keep the project original: use your own name, art, UI, and code rather than copying Diep.io or Arras.io assets.
